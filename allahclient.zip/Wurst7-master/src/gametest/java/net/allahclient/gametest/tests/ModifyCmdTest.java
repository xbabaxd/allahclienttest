/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.allahclient.gametest.tests;

import static net.allahclient.gametest.WurstClientTestHelper.*;

import net.fabricmc.fabric.api.client.gametest.v1.context.ClientGameTestContext;
import net.fabricmc.fabric.api.client.gametest.v1.context.TestServerContext;
import net.fabricmc.fabric.api.client.gametest.v1.context.TestSingleplayerContext;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.allahclient.gametest.WurstTest;

public enum ModifyCmdTest
{
	;
	
	public static void testModifyCmd(ClientGameTestContext context,
		TestSingleplayerContext spContext)
	{
		WurstTest.LOGGER.info("Testing .modify command");
		TestServerContext server = spContext.getServer();
		
		// /give a diamond
		runCommand(server, "give @s diamond");
		context.waitTick();
		assertOneItemInSlot(context, 0, Items.DIAMOND);
		
		// .modify it with NBT data
		runWurstCommand(context,
			"modify set custom_name {\"text\":\"$cRed Name\"}");
		assertOneItemInSlot(context, 0, Items.DIAMOND);
		ItemStack stack = context
			.computeOnClient(mc -> mc.player.getInventory().getSelectedItem());
		String name = stack.getComponents()
			.getOrDefault(DataComponents.CUSTOM_NAME, Component.empty())
			.getString();
		if(!name.equals("\u00a7cRed Name"))
			throw new RuntimeException("Custom name is wrong: " + name);
		runWurstCommand(context, "viewcomp type name");
		context.takeScreenshot("modify_command_result");
		
		// Clean up
		clearInventory(context);
		clearChat(context);
		context.waitTicks(7);
	}
}
