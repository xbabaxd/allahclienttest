/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.allahclient.altmanager;

import java.util.Optional;

import net.minecraft.client.User;
import net.minecraft.core.UUIDUtil;
import net.allahclient.WurstClient;

public enum LoginManager
{
	;
	
	public static void changeCrackedName(String newName)
	{
		User session =
			new User(newName, UUIDUtil.createOfflinePlayerUUID(newName), "",
				Optional.empty(), Optional.empty());
		
		WurstClient.IMC.setWurstSession(session);
	}
}
