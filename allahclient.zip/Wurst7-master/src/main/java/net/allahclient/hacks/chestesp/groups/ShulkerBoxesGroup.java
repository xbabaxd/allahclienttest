/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.allahclient.hacks.chestesp.groups;

import java.awt.Color;

import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.allahclient.hacks.chestesp.ChestEspBlockGroup;
import net.allahclient.settings.CheckboxSetting;
import net.allahclient.settings.ColorSetting;
import net.allahclient.util.LootrModCompat;

public final class ShulkerBoxesGroup extends ChestEspBlockGroup
{
	@Override
	protected CheckboxSetting createIncludeSetting()
	{
		return new CheckboxSetting("Include shulkers", true);
	}
	
	@Override
	protected ColorSetting createColorSetting()
	{
		return new ColorSetting("Shulker color",
			"Shulker boxes will be highlighted in this color.", Color.MAGENTA);
	}
	
	@Override
	protected boolean matches(BlockEntity be)
	{
		return be instanceof ShulkerBoxBlockEntity
			|| LootrModCompat.isLootrShulkerBox(be);
	}
}
