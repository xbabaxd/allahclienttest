/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.allahclient.hacks;

import net.minecraft.client.player.LocalPlayer;
import net.allahclient.Category;
import net.allahclient.SearchTags;
import net.allahclient.events.AirStrafingSpeedListener;
import net.allahclient.events.IsNormalCubeListener;
import net.allahclient.events.PlayerMoveListener;
import net.allahclient.events.VisGraphListener;
import net.allahclient.events.UpdateListener;
import net.allahclient.hack.Hack;

@SearchTags({"no clip"})
public final class NoClipHack extends Hack
	implements UpdateListener, PlayerMoveListener, IsNormalCubeListener,
	VisGraphListener, AirStrafingSpeedListener
{
	public NoClipHack()
	{
		super("NoClip");
		setCategory(Category.MOVEMENT);
	}
	
	@Override
	protected void onEnable()
	{
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(PlayerMoveListener.class, this);
		EVENTS.add(IsNormalCubeListener.class, this);
		EVENTS.add(VisGraphListener.class, this);
		EVENTS.add(AirStrafingSpeedListener.class, this);
	}
	
	@Override
	protected void onDisable()
	{
		EVENTS.remove(UpdateListener.class, this);
		EVENTS.remove(PlayerMoveListener.class, this);
		EVENTS.remove(IsNormalCubeListener.class, this);
		EVENTS.remove(VisGraphListener.class, this);
		EVENTS.remove(AirStrafingSpeedListener.class, this);
		
		MC.player.noPhysics = false;
	}
	
	@Override
	public void onUpdate()
	{
		LocalPlayer player = MC.player;
		
		player.noPhysics = true;
		player.fallDistance = 0;
		player.setOnGround(false);
		
		player.getAbilities().flying = false;
		player.setDeltaMovement(0, 0, 0);
		
		float speed = 0.2F;
		if(MC.options.keyJump.isDown())
			player.push(0, speed, 0);
		if(MC.options.keyShift.isDown())
			player.push(0, -speed, 0);
	}
	
	@Override
	public void onGetAirStrafingSpeed(AirStrafingSpeedEvent event)
	{
		event.setSpeed(0.2F);
	}
	
	@Override
	public void onPlayerMove()
	{
		MC.player.noPhysics = true;
	}
	
	@Override
	public void onIsNormalCube(IsNormalCubeEvent event)
	{
		event.cancel();
	}
	
	@Override
	public void onVisGraph(VisGraphEvent event)
	{
		event.cancel();
	}
}
