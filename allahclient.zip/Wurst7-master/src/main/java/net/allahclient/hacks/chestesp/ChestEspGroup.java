/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.allahclient.hacks.chestesp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;

import net.minecraft.world.phys.AABB;
import net.allahclient.settings.CheckboxSetting;
import net.allahclient.settings.ColorSetting;
import net.allahclient.settings.Setting;

public abstract class ChestEspGroup
{
	protected final ArrayList<AABB> boxes = new ArrayList<>();
	private final ColorSetting color;
	private final CheckboxSetting enabled;
	
	public ChestEspGroup()
	{
		enabled = createIncludeSetting();
		color = createColorSetting();
	}
	
	protected abstract CheckboxSetting createIncludeSetting();
	
	protected abstract ColorSetting createColorSetting();
	
	public void clear()
	{
		boxes.clear();
	}
	
	public final boolean isEnabled()
	{
		return enabled == null || enabled.isChecked();
	}
	
	public final Stream<Setting> getSettings()
	{
		return Stream.of(enabled, color).filter(Objects::nonNull);
	}
	
	public final int getColorI(int alpha)
	{
		return color.getColorI(alpha);
	}
	
	public final List<AABB> getBoxes()
	{
		return Collections.unmodifiableList(boxes);
	}
}
