/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.allahclient.hacks;

import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Player;
import net.allahclient.Category;
import net.allahclient.hack.DontSaveState;
import net.allahclient.hack.Hack;

@DontSaveState
public final class LsdHack extends Hack
{
	public LsdHack()
	{
		super("LSD");
		setCategory(Category.FUN);
	}
	
	@Override
	protected void onEnable()
	{
		if(!(MC.getCameraEntity() instanceof Player))
		{
			setEnabled(false);
			return;
		}
		
		if(MC.gameRenderer.currentPostEffect() != null)
			MC.gameRenderer.clearPostEffect();
		
		MC.gameRenderer
			.setPostEffect(Identifier.fromNamespaceAndPath("allah", "lsd"));
	}
	
	@Override
	protected void onDisable()
	{
		if(MC.gameRenderer.currentPostEffect() != null)
			MC.gameRenderer.clearPostEffect();
	}
}
